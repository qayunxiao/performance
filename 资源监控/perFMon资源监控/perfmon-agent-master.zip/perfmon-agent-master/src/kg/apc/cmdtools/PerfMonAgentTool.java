package kg.apc.cmdtools;

import kg.apc.perfmon.AgentTool;

/**
 * just wrapper to omit package name
 *
 * @author undera
 */
public class PerfMonAgentTool extends AgentTool {
}
