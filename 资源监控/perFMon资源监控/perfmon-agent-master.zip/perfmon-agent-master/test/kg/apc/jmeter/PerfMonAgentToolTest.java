package kg.apc.jmeter;

import junit.framework.TestCase;

/**
 * @author undera
 */
public class PerfMonAgentToolTest extends TestCase {

    public PerfMonAgentToolTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
        super.setUp();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testSomeMethod() {
    }
}
